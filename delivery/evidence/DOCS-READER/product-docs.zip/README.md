# GP Clinic product documentation

Run `npm start`, then open http://localhost:4174. Requires Node.js 22+, with no installation or database.

For a browser WebContainer, import this folder into a Node.js StackBlitz project. The included `.stackblitzrc` starts the reader automatically.

This artifact is a read-only snapshot. Rebuild it from the GP Clinic repository with `pnpm docs:artifact` after changing Markdown. Share the ZIP or deploy `dist/` on a static host for your collaborator.
